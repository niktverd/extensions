#!/usr/bin/bash

cd ~/Desktop/carcentre-backoffice-chrome-extention/ && git pull && chromium-browser http://reload.extensions
