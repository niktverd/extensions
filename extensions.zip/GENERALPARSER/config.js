export const config = {
  'пустое-название': '[Запчасть]',
}
